#!/bin/bash
set -e

# Install the main requirements
pip install -r requirements.txt -r requirements-test.txt

