# Development Roadmap

| Milestone | Status |
|-----------|-------|
| VelocityModel 各パート組込 | ✅ |
# ROADMAP

- bass_generator / piano_generator rests 利用 ✅
- tempo_map E2E ✅
- VelocityModel 各パート組込 🛠 In Progress (CI fix)
