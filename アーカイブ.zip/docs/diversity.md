# Phrase Diversity Filter

`NGramDiversityFilter` compares generated phrases using n‑gram overlap. If similarity exceeds the threshold the phrase can be regenerated. Use higher `n` values or lower `max_sim` for stricter filtering.
