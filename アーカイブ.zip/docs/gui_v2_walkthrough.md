# GUI v2 Walkthrough

<!-- Video removed to avoid binary assets in the repository -->

The second version of the GUI streamlines live playback and editing.
