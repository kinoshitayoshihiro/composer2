# Live Set Example

This example Ableton Live set demonstrates loading the JUCE plugin.

1. Build the plugin under `plugin/`.
2. Copy the generated VST3 to your system plugin folder.
3. Open `Live Set.als` in Ableton to test playback via the plugin.
