Key | Type | Default | Description
--- | ---- | ------- | -----------
drum.fill_density_lut | map<float,float> | see code | Intensity→fill probability
