# ModCompose

This project fuses Japanese narration with emotive musical arrangements. Learn how to install, train models and evaluate your creations.
