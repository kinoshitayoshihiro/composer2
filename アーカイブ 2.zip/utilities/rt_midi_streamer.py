"""Compatibility shim – keep old import path."""
from .rtmidi_streamer import *  # re-export  noqa: F401,F403
